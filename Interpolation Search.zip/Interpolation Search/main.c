#include <stdio.h>
#include <stdlib.h>

#define SIZE 10

int search(int x,int array[])
{
	int low =0;
	int mid= 1;
	int high = SIZE -1;
	
	while(low < high)
	{
		 mid = low   +((high - low) / (array[high]- array[low])) * (x - array[low]);
		 
		 if(array[mid] == x)
		 {
		 	return x;
		 }
		 else if(array[mid ]< x)
		 {
			low = mid +1;		 	
		 }
		else if(array[mid ]> x)
		 {
			high = mid - 1;		 	
		 }
	}
	
	return -1;
}


int main(int argc, char *argv[]) {
	
	int Arr[]={1,2,3,4,5,6,7,8,9};
	int result = search(21,Arr);
	
	printf("The result is : %d",result);
	return 0;
}
